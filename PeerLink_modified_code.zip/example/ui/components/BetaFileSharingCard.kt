package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.filetransfer.BetaFileSharingManager
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonEmerald

@Composable
fun BetaFileSharingCard(
    betaManager: BetaFileSharingManager,
    modifier: Modifier = Modifier
) {
    val isBetaActive by betaManager.isBetaEnabled.collectAsState()
    val targetSpeed by betaManager.targetSpeedMBps.collectAsState()
    val antiBufferbloat by betaManager.antiBufferbloatEnabled.collectAsState()

    val cardBorderColor by animateColorAsState(
        targetValue = if (isBetaActive) NeonEmerald.copy(alpha = 0.7f) else DarkBorder.copy(alpha = 0.6f),
        animationSpec = tween(250),
        label = "border"
    )

    GlassCard(
        borderColor = cardBorderColor,
        modifier = modifier
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row with Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                if (isBetaActive) {
                                    Brush.linearGradient(listOf(NeonEmerald.copy(alpha = 0.35f), CyberCyan.copy(alpha = 0.25f)))
                                } else {
                                    Brush.linearGradient(listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.03f)))
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = if (isBetaActive) NeonEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Sustained High-Speed Pipeline",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isBetaActive) NeonEmerald.copy(alpha = 0.2f) else DarkBorder.copy(alpha = 0.5f))
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = if (isBetaActive) "ACTIVE" else "BURST",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isBetaActive) NeonEmerald else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Text(
                            text = if (isBetaActive) "Paced sustained stream active" else "Toggle on for continuous sustained throughput",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Switch(
                    checked = isBetaActive,
                    onCheckedChange = { betaManager.setBetaEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NeonEmerald,
                        checkedTrackColor = NeonEmerald.copy(alpha = 0.25f),
                        checkedBorderColor = NeonEmerald,
                        uncheckedThumbColor = Color.Gray,
                        uncheckedTrackColor = Color(0xFF151A24),
                        uncheckedBorderColor = DarkBorder
                    )
                )
            }

            // Beta Controls (Visible when active)
            AnimatedVisibility(visible = isBetaActive) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Target Sustained Transfer Rate",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(NeonEmerald.copy(alpha = 0.18f))
                                .border(0.5.dp, NeonEmerald.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "$targetSpeed MB/s",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = NeonEmerald
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Preset 1: 45 MB/s (Safe & Cool)
                        val safeSelected = targetSpeed == 45
                        Button(
                            onClick = { betaManager.setTargetSpeedMBps(45) },
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (safeSelected) CyberCyan else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                contentColor = if (safeSelected) Color(0xFF00363D) else MaterialTheme.colorScheme.onSurface
                            ),
                            border = if (!safeSelected) androidx.compose.foundation.BorderStroke(1.dp, DarkBorder) else null
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("45 MB/s", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("Cool / Safe", fontSize = 8.sp, maxLines = 1)
                            }
                        }

                        // Preset 2: 65 MB/s (Balanced Sustained - Recommended)
                        val balancedSelected = targetSpeed == 65
                        Button(
                            onClick = { betaManager.setTargetSpeedMBps(65) },
                            modifier = Modifier.weight(1.2f).height(44.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (balancedSelected) NeonEmerald else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                contentColor = if (balancedSelected) Color(0xFF003816) else MaterialTheme.colorScheme.onSurface
                            ),
                            border = if (!balancedSelected) androidx.compose.foundation.BorderStroke(1.dp, DarkBorder) else null
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("65 MB/s ★", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("Optimal UFS", fontSize = 8.sp, maxLines = 1)
                            }
                        }

                        // Preset 3: 85 MB/s (Turbo Max)
                        val turboSelected = targetSpeed == 85
                        Button(
                            onClick = { betaManager.setTargetSpeedMBps(85) },
                            modifier = Modifier.weight(1f).height(44.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (turboSelected) ElectricViolet else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                contentColor = if (turboSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            border = if (!turboSelected) androidx.compose.foundation.BorderStroke(1.dp, DarkBorder) else null
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("85 MB/s", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("UFS 4.0", fontSize = 8.sp, maxLines = 1)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Custom Rate Controller (45 - 120 MB/s Slider & Steppers)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .border(1.dp, DarkBorder.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Tune,
                                        contentDescription = null,
                                        tint = CyberCyan,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Custom Rate Controller (45 – 120 MB/s)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                val tierText = when {
                                    targetSpeed <= 55 -> "Safe & Cool"
                                    targetSpeed <= 75 -> "Balanced"
                                    targetSpeed <= 95 -> "Turbo"
                                    else -> "Extreme Peak"
                                }
                                val tierColor = when {
                                    targetSpeed <= 55 -> CyberCyan
                                    targetSpeed <= 75 -> NeonEmerald
                                    targetSpeed <= 95 -> ElectricViolet
                                    else -> Color(0xFFFFB300)
                                }
                                Text(
                                    text = tierText,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = tierColor
                                )
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { betaManager.setTargetSpeedMBps((targetSpeed - 5).coerceAtLeast(45)) },
                                    enabled = targetSpeed > 45,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Decrease Speed",
                                        tint = if (targetSpeed > 45) CyberCyan else Color.Gray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Slider(
                                    value = targetSpeed.toFloat(),
                                    onValueChange = { betaManager.setTargetSpeedMBps(it.toInt()) },
                                    valueRange = 45f..120f,
                                    steps = 74,
                                    modifier = Modifier.weight(1f),
                                    colors = SliderDefaults.colors(
                                        thumbColor = NeonEmerald,
                                        activeTrackColor = NeonEmerald,
                                        inactiveTrackColor = DarkBorder
                                    )
                                )

                                IconButton(
                                    onClick = { betaManager.setTargetSpeedMBps((targetSpeed + 5).coerceAtMost(120)) },
                                    enabled = targetSpeed < 120,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Increase Speed",
                                        tint = if (targetSpeed < 120) CyberCyan else Color.Gray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("45 MB/s (Min)", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("85 MB/s", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("120 MB/s (Max)", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Anti-Bufferbloat Toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .clickable { betaManager.setAntiBufferbloat(!antiBufferbloat) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Default.Wifi,
                                contentDescription = null,
                                tint = if (antiBufferbloat) NeonEmerald else Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Anti-Bufferbloat Window Scaling",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Sub-10ms buffer depth for low network jitter",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = antiBufferbloat,
                            onCheckedChange = { betaManager.setAntiBufferbloat(it) },
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}
