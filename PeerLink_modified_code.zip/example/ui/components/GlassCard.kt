// PeerLink Production Sync - Active
package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.LocalHazeState
import com.example.ui.theme.LocalUiThemeStyle
import com.example.ui.theme.UiThemeStyle
import dev.chrisbanes.haze.HazeStyle
import dev.chrisbanes.haze.HazeTint
import dev.chrisbanes.haze.hazeChild

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 16.dp,
    containerColor: Color? = null,
    borderColor: Color = CyberBorder,
    content: @Composable BoxScope.() -> Unit
) {
    val uiStyle = LocalUiThemeStyle.current
    val isGlassmorphism = uiStyle == UiThemeStyle.GLASSMORPHISM
    val hazeState = LocalHazeState.current

    val resolvedContainerColor = containerColor ?: if (isGlassmorphism) {
        Color.Transparent
    } else {
        CyberCard
    }

    val resolvedBorder = if (isGlassmorphism) {
        if (borderColor == CyberBorder || borderColor == DarkBorder.copy(alpha = 0.6f)) {
            BorderStroke(
                1.dp,
                Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.70f),
                        CyberCyan.copy(alpha = 0.65f),
                        ElectricViolet.copy(alpha = 0.40f),
                        CyberBorder
                    )
                )
            )
        } else {
            BorderStroke(1.dp, borderColor)
        }
    } else {
        BorderStroke(1.dp, borderColor)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(cornerRadius)),
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.cardColors(
            containerColor = resolvedContainerColor
        ),
        border = resolvedBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp) // Avoid M3 dark tonal elevation greyout
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (isGlassmorphism) {
                        Modifier
                            .then(
                                if (hazeState != null) {
                                    Modifier.hazeChild(
                                        state = hazeState,
                                        style = HazeStyle(
                                            backgroundColor = Color(0xFF0C1424).copy(alpha = 0.35f),
                                            tints = listOf(HazeTint(Color(0xFF0C1424).copy(alpha = 0.35f))),
                                            blurRadius = 20.dp
                                        )
                                    )
                                } else {
                                    Modifier
                                }
                            )
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.14f),
                                        Color(0xFF101C33).copy(alpha = 0.45f),
                                        Color(0xFF09101F).copy(alpha = 0.62f)
                                    )
                                )
                            )
                    } else {
                        Modifier
                    }
                )
        ) {
            if (isGlassmorphism) {
                // 1. Top specular reflection line (physical light refraction across top cut edge of glass)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.5.dp)
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.White.copy(alpha = 0.85f),
                                    CyberCyan.copy(alpha = 0.70f),
                                    Color.White.copy(alpha = 0.50f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // 2. Subtle diagonal specular gloss highlight band
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(32.dp)
                        .align(Alignment.TopStart)
                        .padding(top = 4.dp, start = 4.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.60f),
                                    Color.Transparent
                                )
                            )
                        )
                )
            }

            Box(
                modifier = Modifier.padding(16.dp),
                content = content
            )
        }
    }
}
