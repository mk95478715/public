// PeerLink Production Sync - Active
/*
 * PeerLink - Offline Peer-to-Peer Communication Platform
 * File: InternetBoostTileService.kt
 *
 * Commentary / Architectural Overview:
 * Android Quick Settings Notification Shade Tile Service (TileService):
 * - Provides instantaneous 1-tap toggling of Internet Boost directly from
 *   the system Quick Settings panel (even when the app is in the background or during full-screen games).
 * - Reacts to user click events, updating tile state (Tile.STATE_ACTIVE vs Tile.STATE_INACTIVE),
 *   icon, label, and subtitle.
 * - Bidirectionally synchronized with In-App Home Screen HUD via InternetBoostController.
 */

package com.example.service

import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log
import android.widget.Toast
import com.example.R

class InternetBoostTileService : TileService() {
    private val tag = "InternetBoostTile"

    override fun onStartListening() {
        super.onStartListening()
        updateTileUi()
    }

    override fun onClick() {
        super.onClick()
        Log.d(tag, "Quick Settings Tile clicked")
        val isNowBoosted = InternetBoostController.toggleBoost(this)
        updateTileUi()

        val toastText = if (isNowBoosted) {
            "⚡ Internet Boost: ACTIVE (Low-Latency Lock Engaged)"
        } else {
            "Internet Boost: OFF (Standard Power Restored)"
        }
        Toast.makeText(applicationContext, toastText, Toast.LENGTH_SHORT).show()
    }

    private fun updateTileUi() {
        val tile = qsTile ?: return
        val isBoosted = InternetBoostController.isBoostActive.value
        val ping = InternetBoostController.pingMs.value

        tile.state = if (isBoosted) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Internet Boost"
        tile.icon = Icon.createWithResource(this, R.drawable.ic_bolt_tile)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (isBoosted) {
                if (ping != null) "Active • ${ping}ms" else "Active • Low Latency"
            } else {
                "Tap to Boost"
            }
        }

        tile.updateTile()
    }
}
